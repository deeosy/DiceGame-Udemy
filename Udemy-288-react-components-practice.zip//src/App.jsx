import React from "react";
import ReactDOM from "react-dom";
import Heading from "./Heading";

function App() {
  return <Heading />;
}

export default App;
