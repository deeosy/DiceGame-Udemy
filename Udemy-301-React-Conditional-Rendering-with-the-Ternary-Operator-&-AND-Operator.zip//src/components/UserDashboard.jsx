import React from "react";

const currentHour = new Date().getHours();
function UserDashborad() {
  return (
    <div className="">
      <h1>Hello User !</h1>
      {/* {currentHour > 12 ? <h1>Why are you still working?</h1> : null} */}
      {/* a short cut for writing the above statement is which has only an if expression (?) and no else expression (:)   */}
      {/* Below code is called the AND Operator */}
      {currentHour > 12 && <h1>Why are you still working?</h1>}
    </div>
  );
}

export default UserDashborad;
