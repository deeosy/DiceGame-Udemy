import React from "react";
import LoginForm from "./LoginForm";
import UserDashborad from "./UserDashboard";

let isLoggedIn = false;

// function conditionalRendering() {
//   if (isLoggedIn) {
//     return (
// <div className="">
//   <h1>Hello User !</h1>
// </div>
//     );
//   } else {
//     return <LoginForm />;
//   }
// }

// function App() {
//   return <div className="container">{conditionalRendering()} </div>
// }

function App() {
  return (
    <div className="container">
      {isLoggedIn ? (
        <div className="">
          <UserDashborad />
        </div>
      ) : (
        <LoginForm />
      )}
    </div>
  );
}

export default App;
