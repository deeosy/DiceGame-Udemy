import React, { useState } from "react";

// const mouseOver = { backgroundColor: "black" };

function App() {
  const [user, setUser] = useState("");
  const handleUser = (e) => {
    setUser(e.target.value);
  };

  const [headingText, setHeadingText] = useState("Hello");
  const handleClick = () => {
    if (user.length > 0) {
      setHeadingText("Submitted");
      setUser("");
      console.log(user);
    }
  };
  headingText === "Submitted" &&
    setTimeout(() => {
      setHeadingText("Hello");
    }, 2000);

  const [hover, setHover] = useState(false);
  const handleHover = () => {
    setHover(true);
  };
  const handleMouseOut = () => {
    setHover(false);
  };

  return (
    <div className="container">
      <h1>{headingText}</h1>
      <input
        value={user}
        onChange={handleUser}
        type="text"
        placeholder="What's your name?"
      />

      <button
        onClick={handleClick}
        onMouseOver={handleHover}
        onMouseOut={handleMouseOut}
        style={{
          backgroundColor: hover ? "black" : "white",
        }}
      >
        Submit
      </button>
    </div>
  );
}

export default App;
