import React from "react";

function List() {
  return (
    <div className="">
      <ul>
        <li>Bacon</li>
        <li>Jamon</li>
        <li>Noodles</li>
      </ul>
    </div>
  );
}

export default List;
