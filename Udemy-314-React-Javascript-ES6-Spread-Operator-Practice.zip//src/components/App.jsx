import React, { useState } from "react";

function App() {
  const [inputEntry, setInputEntry] = useState("");
  const handleInput = (e) => setInputEntry(e.target.value);

  const [items, setItems] = useState([]);
  const addEntry = () => {
    setItems((previousItems) => [...previousItems, inputEntry]);
    setInputEntry("");
  };

  return (
    <div className="container">
      <div className="heading">
        <h1>To-Do List</h1>
      </div>
      <div className="form">
        <input onChange={handleInput} value={inputEntry} type="text" />
        <button onClick={addEntry}>
          <span>Add</span>
        </button>
      </div>
      <div>
        <ul>
          {items.map((item) => (
            <li>{item}</li>
          ))}
        </ul>
      </div>
    </div>
  );
}

export default App;
