// var numbers = [3, 56, 2, 48, 5];

// //Map -Create a new array by doing something with each item in an array.

// const newNumbers = numbers.map((double) => {
//   return double * 2;
// });

// console.log(newNumbers);

// //Filter - Create a new array by keeping the items that return true.

// const numAboveTen = numbers.filter((num) => {
//   return num > 10;
// });
// console.log(numAboveTen);

// //Reduce - Accumulate a value by doing something to each item in an array.

// const reducedNumbers = numbers.reduce((accumulator, currentNumber) => {
//   // to help understand what is going on lets log both accumulator and currentNumber
//   console.log("accumulator = " + accumulator);
//   console.log("currentNumber = " + currentNumber);
//   return (accumulator += currentNumber);
// }, 0);

// console.log(reducedNumbers);

// //Find - find the first item that matches from an array.

// const findGreaterTen = numbers.find((num) => {
//   return num > 10;
// });

// console.log("first number greater than 10 = " + findGreaterTen);

// //FindIndex - find the index of the first item that matches.

// const findIndexGreaterTen = numbers.findIndex((num) => {
//   return num > 10;
// });
// console.log("Index of first number greater than 10 = " + findIndexGreaterTen);

import emojipedia from "./emojipedia";

// console.log(emojipedia);

const trancatedMeaning = emojipedia.map((emoji) => {
  return emoji.meaning.substring(0, 100);
});
console.log(trancatedMeaning);
