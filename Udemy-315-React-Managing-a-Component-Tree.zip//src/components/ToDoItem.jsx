import React, { useState } from "react";

function ToDoItem({ todoItem, deleteItem, id }) {
  return <li onClick={() => deleteItem(id)}>{todoItem}</li>;

  //       // Below code changes the style on each item upon clicking the item (line-through)
  //   const [doneTask, setDoneTask] = useState(false);
  //   const lineThrough = () => {
  //     // am getting the previousValue of doneTask which is currently false in the useState and getting the opposite by changing the previous value with !. this does the toggle effect
  //     setDoneTask((previousValue) => !previousValue);
  //   };
  //   return (
  //     <li
  //       onClick={lineThrough}
  //       style={{ textDecoration: doneTask ? "line-through" : "none" }}
  //     >
  //       {todoItem}
  //     </li>
  //   );
}

export default ToDoItem;
