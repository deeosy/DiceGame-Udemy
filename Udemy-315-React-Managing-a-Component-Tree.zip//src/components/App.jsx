import React, { useState } from "react";
import ToDoItem from "./ToDoItem";

function App() {
  const [inputText, setInputText] = useState("");
  const [items, setItems] = useState([]);

  function handleChange(event) {
    const newValue = event.target.value;
    setInputText(newValue);
  }

  function addItem() {
    setItems((prevItems) => {
      return [...prevItems, inputText];
    });
    setInputText("");
  }

  const deleteItem = (id) => {
    setItems((previousItems) => {
      return previousItems.filter((item, index) => index !== id);
    });
  };

  return (
    <div className="container">
      <div className="heading">
        <h1>To-Do List</h1>
      </div>
      <div className="form">
        <input onChange={handleChange} type="text" value={inputText} />
        <button onClick={addItem}>
          <span>Add</span>
        </button>
      </div>
      <div>
        <ul>
          {items.map((todoItem, index) => (
            // index above is a variable for the 2nd value of the .map method, hover mouse on the .map method to see 2nd value
            <ToDoItem
              key={index}
              id={index}
              deleteItem={deleteItem}
              todoItem={todoItem}
            />
          ))}
        </ul>
      </div>
    </div>
  );
}

export default App;
