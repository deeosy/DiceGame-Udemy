import React, { useState } from "react";

function CreateArea({ addNote }) {
  const [createNote, setCreateNote] = useState({ title: "", content: "" });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setCreateNote((previousValue) => ({ ...previousValue, [name]: value }));
  };

  const addBtn = (e) => {
    addNote(createNote);
    setCreateNote({ title: "", content: "" });
    e.preventDefault();
  };

  return (
    <div>
      <form>
        <input
          onChange={handleChange}
          value={createNote.title}
          name="title"
          placeholder="Title"
        />
        <textarea
          onChange={handleChange}
          value={createNote.content}
          name="content"
          placeholder="Take a note..."
          rows="3"
        />
        <button onClick={addBtn}>Add</button>
      </form>
    </div>
  );
}

export default CreateArea;
