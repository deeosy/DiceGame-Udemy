import React, { useState } from "react";

function App() {
  // const [fName, setFName] = useState("");
  // const [lName, setLName] = useState("");

  // const handleFName = (e) => {
  //   setFName(e.target.value);
  // };
  // const handleLName = (e) => {
  //   setLName(e.target.value);
  // };

  const [fullName, setFullname] = useState({ fName: "", lName: "" });

  const handleFullname = (e) => {
    // const newValue = e.target.value;
    // const inputName = e.target.name;
    // let destructe the code above
    const { value, name } = e.target;
    // console.log(inputName);
    // console.log(newValue);

    setFullname((preValue) => {
      if (name === "fName") {
        return {
          fName: value,
          lName: preValue.lName,
        };
      } else if (name === "lName") {
        return {
          fName: preValue.fName,
          lName: value,
        };
      }
    });

    console.log(value, name);
  };
  // const [sumbit, setSubmit] = useState("");
  const handleSubmit = (e) => {
    e.preventDefault();
  };

  return (
    <div className="container">
      <h1>
        Hello {fullName.fName} {fullName.lName}
      </h1>
      <form onSubmit={handleSubmit}>
        <input
          value={fullName.fName}
          onChange={handleFullname}
          name="fName"
          placeholder="First Name"
        />
        <input
          name="lName"
          value={fullName.lName}
          onChange={handleFullname}
          placeholder="Last Name"
        />
        <button>Submit</button>
      </form>
    </div>
  );
}

export default App;
