import React, { useState } from "react";
import Header from "./Header";
import Footer from "./Footer";
import Note from "./Note";
import CreateArea from "./CreateArea";

function App() {
  const [notes, setNotes] = useState([]);

  const [createNote, setCreateNote] = useState({ title: "", content: "" });

  const handleChange = (event) => {
    const { name, value } = event.target;
    setCreateNote((previousValue) => {
      return { ...previousValue, [name]: value };
    });
  };

  const addNote = (e) => {
    setNotes((prevNotesArray) => [...prevNotesArray, createNote]);
    setCreateNote({ title: "", content: "" });
    e.preventDefault();
  };

  const deleteNote = (id) => {
    setNotes((prevNotes) => {
      return prevNotes.filter((item, index) => {
        return index !== id;
      });
    });
  };

  // function deleteNote(id) {
  //   setNotes((prevItems) => {
  //     return prevItems.filter((item, index) => {
  //       return index !== id;
  //     });
  //   });
  // }

  return (
    <div>
      <Header />
      <CreateArea
        addNote={addNote}
        handleChange={handleChange}
        createNote={createNote}
      />
      {notes.map((note, index) => {
        return (
          <Note
            title={note.title}
            content={note.content}
            deleteNote={deleteNote}
            id={index}
            key={index}
          />
        );
      })}
      <Footer />
    </div>
  );
}

export default App;
