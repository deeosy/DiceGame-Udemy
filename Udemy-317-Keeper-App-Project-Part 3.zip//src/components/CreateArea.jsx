import React, { useState } from "react";

function CreateArea({ addNote, createNote, handleChange }) {
  return (
    <div>
      <form>
        <input
          onChange={handleChange}
          value={createNote.title}
          name="title"
          placeholder="Title"
        />
        <textarea
          onChange={handleChange}
          value={createNote.content}
          name="content"
          placeholder="Take a note..."
          rows="3"
        />
        <button onClick={addNote}>Add</button>
      </form>
    </div>
  );
}

export default CreateArea;
