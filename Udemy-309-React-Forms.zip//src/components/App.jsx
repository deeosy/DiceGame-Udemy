import React, { useState } from "react";

function App() {
  const [username, setUsername] = useState("");
  const handleUsername = (e) => {
    setUsername(e.target.value);
  };
  const [printUsername, setPrintUsername] = useState("");
  const handlePrint = (e) => {
    setPrintUsername(username);

    e.preventDefault();
  };

  return (
    <div className="container">
      <h1>Hello {printUsername} </h1>
      <form onSubmit={handlePrint}>
        <input
          type="text"
          placeholder="What's your name?"
          onChange={handleUsername}
          value={username}
        />
        <button type="submit">Submit</button>
      </form>
    </div>
  );
}

export default App;
